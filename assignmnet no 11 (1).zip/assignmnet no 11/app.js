 //alert("hello javascript");
 //console.log("hello javascript");

 //var firstPersonName ="zaid";
// alert(firstPersonName);

 //var marks =75;
 //console.log(marks);

 
 //var marks =85;
 //console.log(marks);

 //var a = 10;
 //var b = 20;
 //var c = 30;
 //var d = 60;

 //console.log( a + b - c * d);


 //var a =10;
 //var b =a + 1;
//  var b = a++;

//  console.log( b, "B value");
//  console.log( a, "A value");


// var a =10; 
// var b ="abc";
// var c = a + b;

// console.log(c);
 

// var userName = prompt("Enter your name ");
// var age =prompt("enter your age ");
// console.log(userName,age);

//var a = 10;
//a = 20 ;
//console.log(a)


//var a =prompt("enter your age");
//age = "number";
//console.log(age);

// var age = 15;
// var studentCard = true;

// if (age >= 18) {
//     console.log("Allow");
// } else if (studentCard == true){
//   console.log("allow on Student Card");
// } else {
//     console.log("Not Allow");
// }

// var age = 10;
// var cnic = true
// var studentCard = true;

// if(age >= 18 && cnic == true){
//      console.log("Allow");
// }


// if(age >= 18 || studentCard == true){
//     console.log("Allow");
// }

// var a = "A";
// var b = "B";
 // var arr =(a + b + c + d + e);

// console.log(arr);

// arr[2] = 12;

// console.log(arr);

// arr[3] = "D";

// console.log(arr);

// arr.push("D");
//arr.pop();
//arr.shift();
// arr.unshift("1");

//var a = arr.slice(0 , 3);

// var a = arr.splice(2 , 2 ,"1" , "2");
 

 //console.log(a);
 //console.log(arr);











